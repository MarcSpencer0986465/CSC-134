// M1T1
// Hello World
// Marcus Spencer
// 02/02/2025

#include <iostream>
using namespace std;

int main() {
  cout << "Hello World!\n";
  string name = "Marcus Spencer";
 cout << "Nice to meet you, "<< name << endl; 
}